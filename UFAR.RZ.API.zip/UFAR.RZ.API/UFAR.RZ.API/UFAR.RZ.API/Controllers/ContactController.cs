﻿using Microsoft.AspNetCore.Mvc;
using UFAR.RZ.API.CORE.Services;

namespace UFAR.RZ.API.Controllers {
    public class ContactController : Controller {
        IContactServices services;
        public ContactController(IContactServices services) {
            this.services = services;
        }

        [HttpPost("AddContact")]
        public IActionResult Add(string Name, string Surname) {
            services.AddContact(Name, Surname);
            return Ok();
        }

        [HttpDelete("DeleteContact")]
        public IActionResult Delete(int Id) {
            return Ok(services.DeleteContact(Id));
        }

        [HttpGet("Search")]
        public IActionResult Search(string Name) {
            return Ok(services.GetContact(Name));
        }

        [HttpPost("UpdateContact")]
        public IActionResult Update(int Id, string newName, string newSurname) {
            return Ok(services.UpdateContact(Id, newName, newSurname));
        }
    }
}
