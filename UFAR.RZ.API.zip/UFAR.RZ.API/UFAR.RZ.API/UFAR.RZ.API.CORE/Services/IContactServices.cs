﻿using UFAR.RZ.API.DATA.DAO;
using UFAR.RZ.API.DATA.Entities;

namespace UFAR.RZ.API.CORE.Services
{
    public interface IContactServices
    {
        public ContactEntity? AddContact(string Name, string Surname);

        public ContactEntity? DeleteContact(int Id);

        public List<ContactEntity>? GetContact(string Name);

        public ContactEntity? UpdateContact(int Id, string newName, string newSurname);

    }
}
