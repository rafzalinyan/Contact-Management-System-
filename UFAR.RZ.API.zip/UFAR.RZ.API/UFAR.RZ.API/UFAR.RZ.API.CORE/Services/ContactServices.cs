﻿using UFAR.RZ.API.DATA.DAO;
using UFAR.RZ.API.DATA.Entities;

namespace UFAR.RZ.API.CORE.Services
{
    public class ContactServices : IContactServices
    {
        MainDbContext context;
        public ContactServices(MainDbContext context)
        {
            this.context = context;
        }
        public ContactEntity? AddContact(string name, string surname)
        {
            if ((name == "") || (surname == ""))
            {
                return null;
            }
            ContactEntity contact = new ContactEntity() { Name =  name, Surname = surname };

            context.Contacts.Add(contact);
            context.SaveChanges();

            return contact;
        }

        public ContactEntity? DeleteContact(int Id)
        {
            ContactEntity? contact = context.Contacts.FirstOrDefault(x => x.Id == Id);

            if (contact == null)
            {
                return null;
            } else
            {
                context.Contacts.Remove(contact);
                context.SaveChanges();

                return contact;
            }
        }

        public List<ContactEntity>? GetContact(string Name)
        {
            List<ContactEntity>? list = new List<ContactEntity>();
            foreach (var contact in context.Contacts)
            {
                if (contact.Name == Name)
                {
                    list.Add(contact);
                }
            }
            return list;
        }

        public ContactEntity? UpdateContact(int Id, string newName, string newSurname) {
            ContactEntity? cont = context.Contacts.FirstOrDefault(c => c.Id == Id);

            if (cont == null)
            {
                return null;
            } else if (newName != "")
            {
                cont.Name = newName;
            } else if (newSurname != "")
            {
                cont.Surname = newSurname;
            }

            context.Contacts.Update(cont);
            context.SaveChanges();

            return cont;
        }
    }
}
