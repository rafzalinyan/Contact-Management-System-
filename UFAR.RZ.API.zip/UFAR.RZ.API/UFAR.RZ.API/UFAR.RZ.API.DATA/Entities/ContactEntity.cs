﻿namespace UFAR.RZ.API.DATA.Entities
{
    public class ContactEntity
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public required string Surname { get; set; }
    }
}