﻿using Microsoft.EntityFrameworkCore;
using UFAR.RZ.API.DATA.Entities;

namespace UFAR.RZ.API.DATA.DAO
{
    public class MainDbContext : DbContext
    {
        public MainDbContext(DbContextOptions options) : base(options) { }

        public DbSet<ContactEntity> Contacts { get; set; }
    }
}
